using UnityEngine;

public class BounceReset : MonoBehaviour
{
    private Vector3 startPosition;
    private Rigidbody body;
    private float timer;

    private void Start()
    {
        startPosition = transform.position;
        body = GetComponent<Rigidbody>();
    }

    private void FixedUpdate()
    {
        timer += Time.fixedDeltaTime;
        if (timer < 10f && transform.position.y > -3f) return;

        transform.position = startPosition;
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        timer = 0f;
    }
}
