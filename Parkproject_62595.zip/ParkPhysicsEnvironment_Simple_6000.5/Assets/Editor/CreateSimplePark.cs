using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class CreateSimplePark
{
    private const string ScenePath = "Assets/Scenes/ParkPhysicsEnvironment.unity";

    static CreateSimplePark()
    {
        EditorApplication.delayCall += CreateIfMissing;
    }

    private static void CreateIfMissing()
    {
        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null)
            BuildScene();
    }

    [MenuItem("Park Project/Rebuild Simple Park Scene")]
    public static void BuildScene()
    {
        Folder("Assets", "Scenes");
        Folder("Assets", "Materials");
        Folder("Assets", "Physics Materials");

        Material grass = MakeMaterial("Grass", new Color(0.20f, 0.58f, 0.22f));
        Material brown = MakeMaterial("Brown", new Color(0.42f, 0.20f, 0.07f));
        Material red = MakeMaterial("Red", new Color(0.90f, 0.08f, 0.05f));
        Material blue = MakeMaterial("Blue", new Color(0.05f, 0.35f, 0.90f));
        Material yellow = MakeMaterial("Yellow", new Color(1.00f, 0.65f, 0.05f));

        PhysicsMaterial bounceMaterial = AssetDatabase.LoadAssetAtPath<PhysicsMaterial>(
            "Assets/Physics Materials/Bouncy.physicMaterial");
        if (bounceMaterial == null)
        {
            bounceMaterial = new PhysicsMaterial("Bouncy");
            AssetDatabase.CreateAsset(bounceMaterial,
                "Assets/Physics Materials/Bouncy.physicMaterial");
        }
        bounceMaterial.bounciness = 0.85f;
        bounceMaterial.dynamicFriction = 0.05f;
        bounceMaterial.staticFriction = 0.05f;
        bounceMaterial.bounceCombine = PhysicsMaterialCombine.Maximum;
        bounceMaterial.frictionCombine = PhysicsMaterialCombine.Minimum;
        EditorUtility.SetDirty(bounceMaterial);

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject environment = new GameObject("ENVIRONMENT");
        GameObject parkObjects = new GameObject("PARK OBJECTS");
        GameObject physicsObjects = new GameObject("PHYSICS OBJECTS");

        // Ground Plane with its built-in MeshCollider.
        GameObject ground = Primitive(PrimitiveType.Plane, "Ground_Plane", environment.transform,
            Vector3.zero, new Vector3(2f, 1f, 1.5f), grass);
        ground.isStatic = true;

        // Three simple Cube objects.
        Primitive(PrimitiveType.Cube, "Cube_1_BenchSeat", parkObjects.transform,
            new Vector3(-4f, 1f, 2f), new Vector3(4f, 0.4f, 1.2f), brown).isStatic = true;
        Primitive(PrimitiveType.Cube, "Cube_2_BenchBack", parkObjects.transform,
            new Vector3(-4f, 1.8f, 2.5f), new Vector3(4f, 1.3f, 0.3f), brown).isStatic = true;
        Primitive(PrimitiveType.Cube, "Cube_3_ParkBlock", parkObjects.transform,
            new Vector3(4f, 0.75f, 3f), new Vector3(2f, 1.5f, 2f), yellow).isStatic = true;

        // One Cylinder object.
        Primitive(PrimitiveType.Cylinder, "Cylinder_TreeTrunk", parkObjects.transform,
            new Vector3(-6f, 1.5f, -4f), new Vector3(1f, 1.5f, 1f), brown).isStatic = true;

        // Sphere 1: the bouncing physics demonstration.
        GameObject bouncingSphere = Primitive(PrimitiveType.Sphere, "Sphere_1_Bouncing", physicsObjects.transform,
            new Vector3(0f, 6f, 0f), Vector3.one * 1.2f, red);
        bouncingSphere.GetComponent<SphereCollider>().material = bounceMaterial;
        Rigidbody bounceBody = bouncingSphere.AddComponent<Rigidbody>();
        bounceBody.mass = 1f;
        bounceBody.useGravity = true;
        bounceBody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        bouncingSphere.AddComponent<BounceReset>();

        // Sphere 2: a second Rigidbody with a different mass.
        GameObject secondSphere = Primitive(PrimitiveType.Sphere, "Sphere_2_Rigidbody", physicsObjects.transform,
            new Vector3(4f, 3f, -2f), Vector3.one, blue);
        Rigidbody secondBody = secondSphere.AddComponent<Rigidbody>();
        secondBody.mass = 2f;
        secondBody.useGravity = true;
        secondBody.collisionDetectionMode = CollisionDetectionMode.Continuous;

        // Simple lighting and camera.
        GameObject sun = new GameObject("Directional Light");
        sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        light.shadows = LightShadows.Soft;

        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(12f, 10f, -14f);
        cameraObject.transform.LookAt(new Vector3(0f, 1.5f, 0f));
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.fieldOfView = 55f;
        camera.backgroundColor = new Color(0.55f, 0.75f, 0.95f);
        camera.clearFlags = CameraClearFlags.SolidColor;
        cameraObject.AddComponent<AudioListener>();

        RenderSettings.ambientLight = new Color(0.55f, 0.55f, 0.55f);
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Selection.activeObject = bouncingSphere;
        Debug.Log("Simple ParkPhysicsEnvironment scene created successfully.");
    }

    private static GameObject Primitive(PrimitiveType type, string name, Transform parent,
        Vector3 position, Vector3 scale, Material material)
    {
        GameObject item = GameObject.CreatePrimitive(type);
        item.name = name;
        item.transform.SetParent(parent);
        item.transform.position = position;
        item.transform.localScale = scale;
        item.GetComponent<Renderer>().sharedMaterial = material;
        return item;
    }

    private static Material MakeMaterial(string name, Color color)
    {
        string path = "Assets/Materials/" + name + ".mat";
        Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (material == null)
        {
            material = new Material(Shader.Find("Standard"));
            material.name = name;
            AssetDatabase.CreateAsset(material, path);
        }
        material.color = color;
        EditorUtility.SetDirty(material);
        return material;
    }

    private static void Folder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder(parent + "/" + name))
            AssetDatabase.CreateFolder(parent, name);
    }
}
