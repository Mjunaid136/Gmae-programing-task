# Simple Park Physics Environment

Unity version: **6000.5.0f1**

## Opening the project

1. Extract the ZIP file.
2. In Unity Hub, click **Add project from disk** and select this folder.
3. Open it using Unity **6000.5.0f1**.
4. The simple scene is created automatically the first time the project opens.
5. Open `Assets/Scenes/ParkPhysicsEnvironment.unity` if it is not already open.
6. Press **Play** to watch the red sphere fall and bounce.

## Included requirements

- Ground Plane with Mesh Collider
- Three Cubes with Box Colliders
- Two Spheres with Sphere Colliders
- One Cylinder with Capsule Collider
- Two Rigidbody components with masses 1 and 2
- Gravity enabled
- Bouncy Physics Material with Bounciness 0.85 and Maximum Bounce Combine
- Basic colored materials
- Clearly positioned camera and directional light
- Meaningful object names and organized Hierarchy
- Scene saved as `ParkPhysicsEnvironment`

To regenerate the scene, use **Park Project → Rebuild Simple Park Scene**.
